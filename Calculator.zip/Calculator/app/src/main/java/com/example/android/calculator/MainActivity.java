package com.example.android.calculator;

import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String>,View.OnClickListener {
    Button one,two,three,four,five,six,seven,eight,nine,zero,dec,add,sub,mul,divide,AC,equal; //variable for buttons
    EditText editText;
    TextView txt; //textview for expreesion box
    float c;
    int a,b;
    String exp;
    Socket sock;
    private static final int ON_CREATE_LOADER = 20;
    private static final int ON_SENT_LOADER = 25;
    String error;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        one=(Button)findViewById(R.id.one);
        two=(Button)findViewById(R.id.two);
        three=(Button)findViewById(R.id.three);
        four=(Button)findViewById(R.id.four);
        five=(Button)findViewById(R.id.five);
        six=(Button)findViewById(R.id.six);
        seven=(Button)findViewById(R.id.seven);
        eight=(Button)findViewById(R.id.eight);
        nine=(Button)findViewById(R.id.nine);
        zero=(Button)findViewById(R.id.zero);
        dec=(Button)findViewById(R.id.dec);
        add=(Button)findViewById(R.id.add);
        equal=(Button)findViewById(R.id.equal);
        sub=(Button)findViewById(R.id.sub);
        mul=(Button)findViewById(R.id.mul);
        divide=(Button)findViewById(R.id.divide);
        AC=(Button)findViewById(R.id.AC);
        editText=(EditText)findViewById(R.id.editText);
        txt=(TextView)findViewById(R.id.textView) ;
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);
        zero.setOnClickListener(this);
        sub.setOnClickListener(this);
        add.setOnClickListener(this);
        equal.setOnClickListener(this);
        mul.setOnClickListener(this);
        divide.setOnClickListener(this);
        dec.setOnClickListener(this);
        AC.setOnClickListener(this);

        Bundle queryBundle = new Bundle();
        // Use putString with SEARCH_QUERY_URL_EXTRA as the key and the String value of the URL as the value
        queryBundle.putString("keyOfBundle","ValueofBundle");

        Log.d("TagForTest","TestString");
        LoaderManager loaderManager = getSupportLoaderManager();
        // Get our Loader by calling getLoader and passing the ID we specified
        Loader<String> githubSearchLoader = loaderManager.getLoader(ON_CREATE_LOADER);
        // If the Loader was null, initialize it. Else, restart it.
        if (githubSearchLoader == null) {
            loaderManager.initLoader(ON_CREATE_LOADER,queryBundle, this);
        } else {
            loaderManager.restartLoader(ON_CREATE_LOADER, queryBundle, this);
        }

    }

    // Code for the use for various buttons for calculator

    @Override
    public void onClick(View view){
        switch (view.getId()){
            case R.id.one:editText.setText(editText.getText().toString()+"1");
                txt.setText(txt.getText()+"1");
                break;
            case R.id.two:editText.setText(editText.getText().toString()+"2");
                txt.setText(txt.getText()+"2");
                break;
            case R.id.three:editText.setText(editText.getText().toString()+"3");
                txt.setText(txt.getText()+"3");
                break;
            case R.id.four:editText.setText(editText.getText().toString()+"4");
                txt.setText(txt.getText()+"4");
                break;
            case R.id.five:editText.setText(editText.getText().toString()+"5");
                txt.setText(txt.getText()+"5");
                break;
            case R.id.six:editText.setText(editText.getText().toString()+"6");
                txt.setText(txt.getText()+"6");
                break;
            case R.id.seven:editText.setText(editText.getText().toString()+"7");
                txt.setText(txt.getText()+"7");
                break;
            case R.id.eight:editText.setText(editText.getText().toString()+"8");
                txt.setText(txt.getText()+"8");
                break;
            case R.id.nine:editText.setText(editText.getText().toString()+"9");
                txt.setText(txt.getText()+"9");
                break;
            case R.id.zero:editText.setText(editText.getText().toString()+"0");
                txt.setText(txt.getText()+"0");
                break;
            case R.id.AC:editText.setText("");
                txt.setText("");
                break;
            case R.id.dec:a= Integer.parseInt(editText.getText().toString());
                editText.setText("");
                c='.';
            case R.id.add:a= Integer.parseInt(editText.getText().toString());
                editText.setText("");
                txt.setText(txt.getText()+"+");
                c='+';
                break;
            case R.id.sub:a= Integer.parseInt(editText.getText().toString());
                editText.setText("");
                txt.setText(txt.getText()+"-");
                c='-';
                break;
            case R.id.mul:a= Integer.parseInt(editText.getText().toString());
                editText.setText("");
                txt.setText(txt.getText()+"*");
                c='*';
                break;
            case R.id.divide:a=Integer.parseInt(editText.getText().toString());
                editText.setText("");
                txt.setText(txt.getText()+"/");
                c='/';
                break;
            case  R.id.equal: b=Integer.parseInt(editText.getText().toString());
                exp=txt.getText().toString();
                if (c=='+'){
                    txt.setText(a+b+"");
                    editText.setText("");
                }
                if (c=='-'){
                    txt.setText(a-b+"");
                    editText.setText("");
                }
                if (c=='*'){
                    txt.setText(a*b+"");
                    editText.setText("");
                }
                if (c=='/'){
                    txt.setText(a/b+"");
                    editText.setText("");
                }

                Bundle queryBundle = new Bundle();
                // Use putString with SEARCH_QUERY_URL_EXTRA as the key and the String value of the URL as the value
                queryBundle.putString("keyOfBundle","ValueofBundle");

                Log.d("TagForTest","TestString");
                LoaderManager loaderManager = getSupportLoaderManager();
                // Get our Loader by calling getLoader and passing the ID we specified
                Loader<String> githubSearchLoader = loaderManager.getLoader(ON_SENT_LOADER);
                // If the Loader was null, initialize it. Else, restart it.

                if (githubSearchLoader == null) {
                    loaderManager.initLoader(ON_SENT_LOADER,queryBundle, this);
                } else {
                    loaderManager.restartLoader(ON_SENT_LOADER, queryBundle, this);
                }
                break;
        }


    }

    //Code for socket programming

    @Override
    public Loader<String> onCreateLoader(int id, Bundle args) {

        if(id==ON_CREATE_LOADER) {
            return new AsyncTaskLoader<String>(this) {

                // Override onStartLoading
                @Override
                protected void onStartLoading() {
                    Log.d("onstartloading called", "Done");

                    // Force a load
                    forceLoad();
                }

                // Override loadInBackground
                @Override
                public String loadInBackground() {

                    error = "false";
                    try {

                        Log.d("Connected", "Just connected to ");
                        sock = new Socket();
                        sock.connect(new InetSocketAddress("137.207.82.51", 12345), 5000);  // IP address of alpha.cs.uwindsor.ca and the port number to connect with the server
                        //sock = new Socket(serverName, port);
                        Log.d("Connected", "Just connected to ");

                        Log.d("Connected", "Just connected to " + sock.getRemoteSocketAddress());



                    } catch (Exception e1) {
                        Log.d("Errr", "sorryErrorOccured");
                        error = "true";
                        e1.printStackTrace();
                    }
                    return error;

                }
            };
        }
        else if(id==ON_SENT_LOADER){
            Log.d("onsentloader","beforestart");
            return new AsyncTaskLoader<String>(this) {
                @Override
                protected void onStartLoading() {
                    Log.d("onstartloading called", "onStartLoading");

                    forceLoad();
                }
                @Override
                public String loadInBackground() {
                    try {
                        Log.d("onsentloader","started");
                        OutputStream ostream = sock.getOutputStream();
                        PrintWriter pwrite = new PrintWriter(ostream, true);
                        InputStream istream = sock.getInputStream();
                        BufferedReader receiveRead = new BufferedReader(new InputStreamReader(istream));
                        String receiveMessage, sendMessage;
                        sendMessage = exp.toString() + "\n";//keyRead.readLine();  // keyboard reading
                        pwrite.println(sendMessage);       // sending to server
                        pwrite.flush();                    // flush the data
                        List<String> tempStringList = new ArrayList<String>();
                        ;
//
                        Log.d("onsentloader","beforereading");
                        receiveMessage = receiveRead.readLine();
                        Log.d("ReceivedFromServer", receiveMessage); // displaying at DOS prompt
                        tempStringList.add(receiveMessage);
                        error = receiveMessage;
                        Log.d("onsentloader","ended");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return error;
                }
            };

        }

        return null;
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String data) {
        if(loader.getId() == ON_CREATE_LOADER) {

            Log.d("OnloadfinshedONCREATE", "OnCreate");
        }
        else {
            txt.setText(data);
            Log.d("OnloadfinshedONSENT", "OnSent");
        }
    }

    @Override
    public void onLoaderReset(Loader<String> loader) {

    }


}
